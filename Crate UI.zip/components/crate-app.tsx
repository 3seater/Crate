'use client'

import { useState } from 'react'

export type Crate = {
  name: string
  ticker: string
  description: string
  category: string
  change: string
  color: string
  tokens: { symbol: string; weight: number; color: string }[]
}

export const crates: Crate[] = [
  {
    name: 'The Builders',
    ticker: 'BUILD',
    description: 'The rails, tools, and protocols moving the onchain economy forward.',
    category: 'Infrastructure',
    change: '+18.42%',
    color: '#f0a56a',
    tokens: [
      { symbol: 'BASE', weight: 34, color: '#d4b2ff' },
      { symbol: 'AERO', weight: 28, color: '#f0a56a' },
      { symbol: 'DEGEN', weight: 22, color: '#8c7bb5' },
      { symbol: 'TOSHI', weight: 16, color: '#b9a4c9' },
    ],
  },
  {
    name: 'Onchain Summer',
    ticker: 'SUMMER',
    description: 'High-conviction culture coins with a little more heat in the mix.',
    category: 'Culture',
    change: '+24.06%',
    color: '#f6bd86',
    tokens: [
      { symbol: 'BRETT', weight: 38, color: '#f0b2c9' },
      { symbol: 'DEGEN', weight: 27, color: '#caa5f5' },
      { symbol: 'TOSHI', weight: 20, color: '#8d779e' },
      { symbol: 'MOG', weight: 15, color: '#e3cfda' },
    ],
  },
  {
    name: 'Quiet Conviction',
    ticker: 'SIGNAL',
    description: 'A measured mix for people who like their signal clean and their noise low.',
    category: 'Core',
    change: '+9.81%',
    color: '#d8a878',
    tokens: [
      { symbol: 'ETH', weight: 42, color: '#d7c3f1' },
      { symbol: 'cbBTC', weight: 31, color: '#e4b4c9' },
      { symbol: 'AERO', weight: 15, color: '#927fa9' },
      { symbol: 'USDC', weight: 12, color: '#b8a7c3' },
    ],
  },
]

function Mark() {
  return <img className="crate-logo" src="/crate-logo.svg" alt="Crate" />
}

export function CrateCard({ crate, onSelect = () => {} }: { crate: Crate; onSelect?: (crate: Crate) => void }) {
  return (
    <article className="crate-card">
      <div className="crate-topline"><span className="eyebrow">{crate.category}</span><span className="live-dot">Live</span></div>
      <div className="crate-card-heading">
        <div><h3>{crate.name}</h3><p className="ticker">${crate.ticker}</p></div>
        <div className="crate-orb" style={{ '--orb': crate.color } as React.CSSProperties}><span>{crate.tokens[0].symbol.slice(0, 2)}</span></div>
      </div>
      <p className="crate-desc">{crate.description}</p>
      <div className="allocation-row">{crate.tokens.map((token) => <div key={token.symbol} style={{ width: `${token.weight}%`, background: token.color }} />)}</div>
      <div className="token-list">{crate.tokens.map((token) => <span key={token.symbol}>{token.symbol} <b>{token.weight}%</b></span>)}</div>
      <div className="crate-footer"><span className="change">{crate.change} <small>30d</small></span><button className="text-button" onClick={() => onSelect(crate)}>Open crate</button></div>
    </article>
  )
}

export default function CrateApp() {
  const [connected, setConnected] = useState(false)
  const [walletOpen, setWalletOpen] = useState(false)
  const [selected, setSelected] = useState<Crate | null>(null)
  const [amount, setAmount] = useState('100')
  const [bought, setBought] = useState(false)

  const chooseCrate = (crate: Crate) => { setSelected(crate); setBought(false); setAmount('100') }

  return (
    <main className="site-shell">
      <nav className="nav"><a className="brand" href="#top"><Mark /><span>crate</span></a><div className="nav-links"><a href="/crates">Crates</a><a href="#steps">How it works</a><a href="#faq">FAQ</a></div><button className="connect-button" onClick={() => connected ? setConnected(false) : setWalletOpen(true)}>{connected ? '0x71...4C2A' : 'Connect wallet'}</button></nav>

      <section className="hero" id="top"><div className="hero-copy"><h1>Make your<br /><em>own</em> market.</h1><p className="hero-sub">Crate is a simpler way to get exposure to the tokens that belong together. One decision. One transaction. No tab hoarding.</p><div className="hero-actions"><a className="primary-button" href="#crates">Explore crates</a><a className="ghost-button" href="#steps">How it works</a></div></div><div className="hero-art"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="prism"><span>CRATE</span><small>001</small></div></div></section>

      <section className="statement" id="method"><h2>Not another token.<br /><span>A better way to see them.</span></h2><p className="statement-copy">Markets are made of stories, sectors, and strange little constellations. Crates package those relationships into a single, transparent onchain buy.</p></section>

      <section className="steps" id="steps"><div className="steps-grid"><div><span>01</span><h3>Pick a point of view.</h3><p>Choose a crate built around a sector, a thesis, or just a feeling.</p></div><div><span>02</span><h3>Set your amount.</h3><p>Tell us how much you want to put in. We handle the proportions.</p></div><div><span>03</span><h3>Sign once.</h3><p>Your wallet receives every token in a single, transparent transaction.</p></div></div></section>

      <section className="crates-section" id="crates"><div className="section-header"><div><h2>Browse the crates.</h2></div><a className="text-button" href="/crates">View all nine crates</a></div><div className="crate-grid">{crates.map((crate) => <CrateCard key={crate.ticker} crate={crate} onSelect={chooseCrate} />)}</div></section>

      <section className="closing" id="faq"><h2>Find your<br /><em>crate.</em></h2><button className="primary-button" onClick={() => document.getElementById('crates')?.scrollIntoView({ behavior: 'smooth' })}>Explore the collection</button></section>
      <footer><a className="brand" href="#top"><Mark /><span>crate</span></a><span>Curated token indexes for Robinhood Chain.</span><span>© 2026 Crate</span></footer>

      {walletOpen && <div className="modal-backdrop" onClick={() => setWalletOpen(false)}><div className="wallet-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setWalletOpen(false)}>×</button><Mark /><p className="section-index">Connect to continue</p><h2>Your wallet,<br /><em>your call.</em></h2><p>Choose a wallet to enter the Crate preview. This is a simulated connection for now.</p><div className="wallet-options"><button onClick={() => { setConnected(true); setWalletOpen(false) }}>Coinbase Wallet</button><button onClick={() => { setConnected(true); setWalletOpen(false) }}>MetaMask</button><button onClick={() => { setConnected(true); setWalletOpen(false) }}>WalletConnect</button></div></div></div>}
      {selected && <div className="modal-backdrop" onClick={() => setSelected(null)}><div className="buy-modal" onClick={(event) => event.stopPropagation()}><button className="modal-close" onClick={() => setSelected(null)}>×</button><div className="buy-heading"><div><p className="section-index">Selected crate</p><h2>{selected.name}</h2><p className="ticker">${selected.ticker}</p></div><div className="crate-orb large" style={{ '--orb': selected.color } as React.CSSProperties}><span>{selected.tokens[0].symbol.slice(0, 2)}</span></div></div><div className="buy-amount"><label htmlFor="amount">Amount to allocate</label><div><span>$</span><input id="amount" value={amount} onChange={(event) => setAmount(event.target.value.replace(/[^0-9.]/g, ''))} /><span>USD</span></div></div><div className="buy-breakdown">{selected.tokens.map((token) => <div key={token.symbol}><span><i style={{ background: token.color }} />{token.symbol}</span><b>{token.weight}% · ${((Number(amount) || 0) * token.weight / 100).toFixed(2)}</b></div>)}</div><button className="primary-button full" onClick={() => connected ? setBought(true) : setWalletOpen(true)}>{bought ? 'Allocation prepared' : connected ? 'Review allocation' : 'Connect wallet to continue'}</button>{bought && <p className="success-note">Demo only — your transaction is not being submitted.</p>}</div></div>}
    </main>
  )
}
