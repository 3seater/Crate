import Link from 'next/link'

const catalog = [
  ['The Builders','BUILD','Infrastructure','+18.42%','The rails, tools, and protocols moving the onchain economy forward.'],
  ['Onchain Summer','SUMMER','Culture','+24.06%','High-conviction culture coins with a little more heat in the mix.'],
  ['Quiet Conviction','SIGNAL','Core','+9.81%','A measured mix for people who like their signal clean.'],
  ['Stable Ground','GROUND','Core','+12.07%','A steadier basket for building a long-term onchain base.'],
  ['Meme Frequency','FREQ','Culture','+31.20%','The loudest signals from the culture layer, packaged together.'],
  ['Base Layer','LAYER','Infrastructure','+15.88%','The essential assets underneath the next internet.'],
  ['Night Shift','NIGHT','Emerging','+21.46%','Early signals for the curious, with room to move.'],
  ['Open Source','SOURCE','Infrastructure','+16.63%','The builders and communities making crypto more useful.'],
  ['First Principles','PRIME','Core','+7.94%','A focused mix of foundational tokens and clean signal.'],
]

export default function CratesPage() {
  return <main className="site-shell"><nav className="nav"><Link className="brand" href="/"><img className="crate-logo" src="/crate-logo.svg" alt="Crate" /><span>crate</span></Link><div className="nav-links"><Link href="/">Overview</Link><Link href="/crates">Crates</Link><Link href="/#method">How it works</Link></div><button className="connect-button">Connect wallet</button></nav><section className="catalog-hero"><h1>All <em>crates.</em></h1><p>Curated token indexes for different convictions, sectors, and seasons. Choose a point of view, then choose your size.</p></section><section className="crates-section catalog-section"><div className="section-header"><div><h2>Find your mix.</h2></div><Link className="ghost-button" href="/">Back to overview</Link></div><div className="crate-grid">{catalog.map(([name, ticker, category, change, description], index) => <article className="crate-card" key={ticker}><div className="crate-topline"><span className="eyebrow">{category}</span><span className="live-dot">Live</span></div><div className="crate-card-heading"><div><h3>{name}</h3><p className="ticker">${ticker}</p></div><div className="crate-orb" style={{ '--orb': ['#f0a56a','#f6bd86','#d8a878'][index % 3] } as React.CSSProperties}><span>{ticker.slice(0, 2)}</span></div></div><p className="crate-desc">{description}</p><div className="allocation-row"><div style={{ width: '34%', background: '#d4b2ff' }} /><div style={{ width: '28%', background: '#f0a56a' }} /><div style={{ width: '22%', background: '#8c7bb5' }} /><div style={{ width: '16%', background: '#b9a4c9' }} /></div><div className="token-list"><span>CORE <b>34%</b></span><span>GROWTH <b>28%</b></span><span>EDGE <b>22%</b></span></div><div className="crate-footer"><span className="change">{change} <small>30d</small></span><button className="text-button">Open crate</button></div></article>)}</div></section><footer><Link className="brand" href="/"><img className="crate-logo" src="/crate-logo.svg" alt="Crate" /><span>crate</span></Link><span>Curated token indexes for Robinhood Chain.</span><span>© 2026 Crate</span></footer></main>
}
