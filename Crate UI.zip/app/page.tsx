import CrateApp from '@/components/crate-app'

export default function Page() {
  return <CrateApp />
}
